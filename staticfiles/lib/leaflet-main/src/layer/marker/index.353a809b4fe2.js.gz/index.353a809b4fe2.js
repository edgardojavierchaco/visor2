import {Icon} from './Icon.js';
export {icon} from './Icon.js';
import {IconDefault} from './Icon.Default.js';
Icon.Default = IconDefault;
export {Icon};

export {DivIcon, divIcon} from './DivIcon.js';
export {Marker, marker} from './Marker.js';
