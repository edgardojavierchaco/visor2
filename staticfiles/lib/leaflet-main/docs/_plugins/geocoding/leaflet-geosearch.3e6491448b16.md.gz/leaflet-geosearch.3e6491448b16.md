---
name: Leaflet GeoSearch
category: geocoding
repo: https://github.com/smeijer/leaflet-geosearch
author: Stephan Meijer
author-url: https://github.com/smeijer
demo: https://smeijer.github.io/leaflet-geosearch/
compatible-v0:
compatible-v1: true
---

Small geocoding plugin that brings address searching/lookup (aka geosearching) to Leaflet.<br>			Comes with support for Google, OpenStreetMap Nominatim, Bing, Esri and Nokia. Easily extensible.
