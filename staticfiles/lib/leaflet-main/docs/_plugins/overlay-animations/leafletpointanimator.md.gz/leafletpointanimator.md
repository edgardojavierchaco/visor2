---
name: leaflet-point-animator
category: overlay-animations
repo: https://github.com/onaci/leaflet-point-animator
author: danwild
author-url: https://github.com/danwild
demo: https://onaci.github.io/leaflet-point-animator/
compatible-v0:
compatible-v1: true
---

Animate a large number of GeoJSON points.
