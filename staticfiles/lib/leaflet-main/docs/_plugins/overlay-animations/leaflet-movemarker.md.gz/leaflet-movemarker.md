---
name: Leaflet.MoveMarker
category: overlay-animations
repo: https://github.com/dekguh/Leaflet.MoveMarker
author: I Kadek Teguh Mahesa
author-url: https://github.com/dekguh
demo: https://real-demo-leaflet-movemarker.netlify.app
compatible-v0: false
compatible-v1: true
---

Used to create moving marker animation and also trail polyline animation.
