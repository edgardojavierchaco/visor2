---
name: Leaflet.MarkerPlayer
category: overlay-animations
repo: https://github.com/0n3byt3/Leaflet.MarkerPlayer
author: 0n3byt3
author-url: https://github.com/0n3byt3
demo: https://0n3byt3.github.io/
compatible-v0:
compatible-v1: true
---

A plug-in for animating marker along polyline with ability to get/set progress.
