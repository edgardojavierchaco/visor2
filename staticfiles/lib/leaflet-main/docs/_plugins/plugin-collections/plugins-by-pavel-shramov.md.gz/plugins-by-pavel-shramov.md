---
name: Plugins by Pavel Shramov
category: plugin-collections
repo: https://github.com/shramov/leaflet-plugins
author: Pavel Shramov
author-url: https://github.com/shramov
demo: 
compatible-v0:
compatible-v1: true
---

A set of plugins for: GPX, KML, TOPOJSON layers; Bing tile layer; Yandex layers (implemented with their APIs), and permalink control.
