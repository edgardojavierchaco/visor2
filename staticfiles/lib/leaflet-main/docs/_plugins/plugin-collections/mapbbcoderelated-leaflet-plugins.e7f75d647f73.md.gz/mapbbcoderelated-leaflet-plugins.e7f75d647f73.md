---
name: MapBBCode-related leaflet plugins
category: plugin-collections
repo: http://mapbbcode.org/leaflet.html
author: Ilya Zverev
author-url: https://github.com/zverik
demo: 
compatible-v0:
compatible-v1: true
---

Seven plugins for various features, independent of the MapBBCode library.			From circular and popup icons to buttons, layer switcher, better search and attribution.
