---
name: Leaflet.Antimeridian
category: geoprocessing
repo: https://github.com/briannaAndCo/Leaflet.Antimeridian
author: Brianna Landon
author-url: https://github.com/briannaAndCo
demo: https://briannaandco.github.io/Leaflet.Antimeridian/
compatible-v0:
compatible-v1: true
---

A plugin to allow polygons and polylines to naturally draw across the Antimeridian (or the International Date Line) instead of always wrapping across the Greenwich meridian.
