---
name: leaflet-spatial-prefix-tree
category: geoprocessing
repo: https://github.com/missinglink/leaflet-spatial-prefix-tree
author: Mapzen
author-url: https://mapzen.com/
demo: https://missinglink.github.io/leaflet-spatial-prefix-tree/
compatible-v0:
compatible-v1: true
---

Leaflet plugin for visualizing spatial prefix trees, quadtree and geohash.
