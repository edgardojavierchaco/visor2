---
name: Leaflet.Graticule
category: synthetic-overlays
repo: https://github.com/turban/Leaflet.Graticule
author: Bjørn Sandvik
author-url: https://github.com/turban
demo: 
compatible-v0:
compatible-v1: true
---

Draws a grid of latitude and longitude lines.
