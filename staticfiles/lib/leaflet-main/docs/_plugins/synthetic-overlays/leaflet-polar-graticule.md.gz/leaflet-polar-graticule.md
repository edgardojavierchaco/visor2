---
name: Leaflet.PolarGraticule
category: synthetic-overlays
repo: https://github.com/anton-seaice/Leaflet.PolarGraticule
author: Anton Steketee
author-url: https://github.com/anton-seaice
demo: https://anton-seaice.github.io/Leaflet.PolarGraticule/examples/antarctic.html
compatible-v0:
compatible-v1: true
---

Draws a projection aware grid of latitude and longitude lines, with labels on the lines and options to set the extent of and interval between the lines.
