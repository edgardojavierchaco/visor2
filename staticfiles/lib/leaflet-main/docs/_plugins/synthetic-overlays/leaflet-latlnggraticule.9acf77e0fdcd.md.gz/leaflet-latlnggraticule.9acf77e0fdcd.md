---
name: leaflet.latlng-graticule
category: synthetic-overlays
repo: https://github.com/cloudybay/leaflet.latlng-graticule
author: CloudyBay
author-url: https://github.com/cloudybay/
demo: https://cloudybay.github.io/leaflet.latlng-graticule/example/
compatible-v0:
compatible-v1: true
---

Create a Canvas as ImageOverlay to draw the Lat/Lon Graticule, and show the grid tick label at the edges of the map.
