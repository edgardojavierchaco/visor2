---
name: Leaflet.EdgeScaleBar
category: synthetic-overlays
repo: https://github.com/dtutic/Leaflet.EdgeScaleBar
author: Dražen Tutić, Ana Kuveždić Divjak
author-url: https://github.com/GEOF-OSGL
demo:
compatible-v0:
compatible-v1: true
---

Creates scale bars along top and right edge of a map in the Web Mercator projection.
