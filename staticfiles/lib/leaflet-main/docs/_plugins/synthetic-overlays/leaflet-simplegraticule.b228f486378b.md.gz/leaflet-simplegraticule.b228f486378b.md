---
name: Leaflet.SimpleGraticule
category: synthetic-overlays
repo: https://github.com/ablakey/Leaflet.SimpleGraticule
author: Andrew Blakey
author-url: https://github.com/ablakey
demo: 
compatible-v0:
compatible-v1: true
---

Draws a grid lines for L.CRS.Simple coordinate system.
