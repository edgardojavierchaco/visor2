---
name: Leaflet.Terminator
category: synthetic-overlays
repo: https://github.com/joergdietrich/Leaflet.Terminator
author: Jörg Dietrich
author-url: https://github.com/joergdietrich
demo: 
compatible-v0:
compatible-v1: true
---

Overlay day and night regions on a map.
