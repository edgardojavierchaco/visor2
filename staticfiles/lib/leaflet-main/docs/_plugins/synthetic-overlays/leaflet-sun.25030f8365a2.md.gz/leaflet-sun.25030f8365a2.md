---
name: Leaflet.Sun
category: synthetic-overlays
repo: https://github.com/dj0001/Leaflet.Sun
author: DJ
author-url: https://github.com/dj0001
demo: https://dj0001.github.io/Leaflet.Sun/
compatible-v0:
compatible-v1: true
---

Get sunset or sunrise at map click.
