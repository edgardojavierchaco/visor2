---
name: Leaflet.NonTiledLayers
category: tile-image-display
repo: https://github.com/ptv-logistics/Leaflet.NonTiledLayer
author: PTV Logistics
author-url: https://github.com/ptv-logistics
demo: https://ptv-logistics.github.io/Leaflet.NonTiledLayer/index.html
compatible-v0:
compatible-v1: true
---

A Leaflet layer for non-tiled overlays.
