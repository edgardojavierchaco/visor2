---
name: Leaflet.ImageOverlay.Rotate
category: tile-image-display
repo: https://github.com/IvanSanchez/Leaflet.ImageOverlay.Rotated
author: Iván Sánchez Ortega
author-url: https://github.com/IvanSanchez
demo: http://ivansanchez.github.io/Leaflet.ImageOverlay.Rotated/demo.html
compatible-v0:
compatible-v1: true
---

Displays rotated, scaled and skewed (but not rubbersheeted) ImageOverlays, given three control points. 
