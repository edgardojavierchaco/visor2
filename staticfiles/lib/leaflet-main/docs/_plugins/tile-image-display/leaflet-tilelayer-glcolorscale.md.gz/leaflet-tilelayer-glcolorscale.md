---
name: Leaflet.TileLayer.GLColorScale
category: tile-image-display
repo: https://github.com/ihmeuw/leaflet.tilelayer.glcolorscale
author: David Schneider
author-url: https://github.com/davschne
demo: https://ihmeuw.github.io/leaflet.tilelayer.glcolorscale/demo/
compatible-v0:
compatible-v1: true
---

TileLayer that uses WebGL to colorize floating-point pixels according to a specified color scale.
