---
name: TileLayer.Grayscale
category: tile-image-display
repo: https://github.com/Zverik/leaflet-grayscale/
author: Ilya Zverev
author-url: https://github.com/Zverik
demo: 
compatible-v0:
compatible-v1: true
---

A regular TileLayer with grayscale makeover.
