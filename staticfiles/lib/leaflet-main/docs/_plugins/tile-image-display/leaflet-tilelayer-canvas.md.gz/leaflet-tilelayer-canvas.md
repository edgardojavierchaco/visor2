---
name: Leaflet.TileLayer.Canvas
category: tile-image-display
repo: https://github.com/GIAPspzoo/L.TileLayer.Canvas
author: GIAP
author-url: https://giap.pl
demo: 
compatible-v0:
compatible-v1: true
---

Render tiles as canvas elements.
