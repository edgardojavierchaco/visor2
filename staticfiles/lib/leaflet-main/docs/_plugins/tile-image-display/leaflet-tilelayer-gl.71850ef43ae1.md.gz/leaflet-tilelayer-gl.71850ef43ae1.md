---
name: Leaflet.TileLayer.GL
category: tile-image-display
repo: https://gitlab.com/IvanSanchez/Leaflet.TileLayer.GL
author: Iván Sánchez
author-url: https://github.com/IvanSanchez
demo: https://ivansanchez.gitlab.io/Leaflet.TileLayer.GL/demo/repl.html
compatible-v0:
compatible-v1: true
---

Applies custom WebGL shaders to each tile in a tilelayer.
