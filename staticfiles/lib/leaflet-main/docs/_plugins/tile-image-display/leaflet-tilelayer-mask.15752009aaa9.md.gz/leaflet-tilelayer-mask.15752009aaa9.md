---
name: Leaflet.TileLayer.Mask
category: tile-image-display
repo: https://github.com/frogcat/leaflet-tilelayer-mask
author: Yuzo Matsuzawa
author-url: https://github.com/frogcat
demo: http://frogcat.github.io/leaflet-tilelayer-mask/default/
compatible-v0:
compatible-v1: true
---

A TileLayer with mask effect.
