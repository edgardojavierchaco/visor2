---
name: TileLayer.BoundaryCanvas
category: tile-image-display
repo: https://github.com/aparshin/leaflet-boundary-canvas
author: Alexander Parshin
author-url: https://github.com/aparshin
demo: 
compatible-v0:
compatible-v1: true
---

Allows you to draw tile layers with arbitrary polygonal boundary. HTML Canvas is used for rendering.
