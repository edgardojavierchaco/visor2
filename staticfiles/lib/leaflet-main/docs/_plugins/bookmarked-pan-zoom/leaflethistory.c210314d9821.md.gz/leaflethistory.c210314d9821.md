---
name: Leaflet-History
category: bookmarked-pan-zoom
repo: https://github.com/cscott530/leaflet-history
author: Chris Scott
author-url: https://github.com/cscott530
demo: https://cscott530.github.io/leaflet-history/
compatible-v0:
compatible-v1: true
---

Track history of map movements and zoom locations similar to a browser.
