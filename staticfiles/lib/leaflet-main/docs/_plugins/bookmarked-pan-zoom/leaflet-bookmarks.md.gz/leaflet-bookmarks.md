---
name: Leaflet.Bookmarks
category: bookmarked-pan-zoom
repo: https://github.com/w8r/Leaflet.Bookmarks
author: Alexander Milevski
author-url: https://github.com/w8r/
demo: https://milevski.co/Leaflet.Bookmarks/
compatible-v0:
compatible-v1: true
---

Control for adding and navigating between user-created bookmarks on the map.
