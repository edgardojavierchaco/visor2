---
name: leaflet-hash
category: bookmarked-pan-zoom
repo: https://github.com/mlevans/leaflet-hash
author: Michael Lawrence Evans
author-url: https://github.com/mlevans
demo: https://mlevans.com/leaflet-hash/map.html
compatible-v0:
compatible-v1: true
---

Plugin for persisting map state and browsing history through the URL hash.
