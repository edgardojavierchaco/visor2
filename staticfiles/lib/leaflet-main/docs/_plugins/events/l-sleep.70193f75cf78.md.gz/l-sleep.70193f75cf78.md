---
name: L.Sleep
category: events
repo: https://github.com/CliffCloud/Leaflet.Sleep
author: atstp
author-url: https://github.com/atstp
demo: https://cliffcloud.github.io/Leaflet.Sleep/
compatible-v0:
compatible-v1: true
---

Avoid unwanted scroll capturing.
