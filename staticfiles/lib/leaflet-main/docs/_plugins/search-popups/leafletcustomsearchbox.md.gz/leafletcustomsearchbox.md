---
name: leaflet-custom-searchbox
category: search-popups
repo: https://github.com/8to5Developer/leaflet-custom-searchbox
author: A.D
author-url: https://github.com/8to5Developer/
demo: https://8to5developer.github.io/leaflet-custom-searchbox/
compatible-v0:
compatible-v1: true
---

A google map style search box which includes a side panel slider control.
