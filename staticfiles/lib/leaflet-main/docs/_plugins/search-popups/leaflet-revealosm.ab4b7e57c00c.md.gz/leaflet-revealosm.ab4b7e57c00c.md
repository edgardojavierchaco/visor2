---
name: Leaflet.RevealOSM
category: search-popups
repo: https://github.com/yohanboniface/Leaflet.RevealOSM
author: Yohan Boniface
author-url: https://yohanboniface.me/
demo: 
compatible-v0:
compatible-v1: true
---

Very simple but extendable Leaflet plugin to display OSM POIs data on map click.
