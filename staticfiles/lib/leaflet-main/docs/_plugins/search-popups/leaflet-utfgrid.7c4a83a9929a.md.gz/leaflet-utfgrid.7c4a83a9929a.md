---
name: Leaflet.utfgrid
category: search-popups
repo: https://github.com/danzel/Leaflet.utfgrid
author: Dave Leaver
author-url: https://github.com/danzel
demo: 
compatible-v0: false
compatible-v1: true
---

Provides a utfgrid interaction handler for leaflet a very small footprint.
support for Leaflet &gt;= 1.0.  Includes basic mouseover support plus ability to highlight feature from UTFGrid on hover.
