---
name: Leaflet.GeoJSONAutocomplete
category: search-popups
repo: https://github.com/utahemre/Leaflet.GeoJSONAutocomplete
author: Yunus Emre Özkaya
author-url: https://github.com/utahemre
demo: https://utahemre.github.io/geojsonautocompletedemo.html
compatible-v0:
compatible-v1: true
---

Leaflet Autocomplete For Remote Searching with GeoJSON Services.
