---
name: Leaflet Underneath
category: search-popups
repo: https://github.com/perliedman/leaflet-underneath
author: Per Liedman
author-url: https://github.com/perliedman
demo: 
compatible-v0:
compatible-v1: true
---

Find interesting features near a location using Mapbox Vector Tiles data, to add			interactive functionality to a tile layer with speed and limited bandwidth.
