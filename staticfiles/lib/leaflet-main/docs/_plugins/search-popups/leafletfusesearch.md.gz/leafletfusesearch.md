---
name: leaflet-fusesearch
category: search-popups
repo: https://github.com/naomap/leaflet-fusesearch
author: Antoine Riche
author-url: https://github.com/naomap
demo: http://dev.cartocite.fr/CultureNantes/
compatible-v0: http://dev.cartocite.fr/CultureNantes/
compatible-v1: true
---

A control that provides a panel to search features in a GeoJSON layer using the lightweight fuzzy search Fuse.js
