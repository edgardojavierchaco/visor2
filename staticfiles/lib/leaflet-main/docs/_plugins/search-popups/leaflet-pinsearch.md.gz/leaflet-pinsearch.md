---
name: Leaflet PinSearch
category: search-popups
repo: https://github.com/MokahalA/Leaflet.PinSearch
author: Ahmad El Mokahal
author-url: https://mokahala.github.io/
demo: https://mokahala.github.io/hosting/Leaflet.PinSearch/index.html
compatible-v0:
compatible-v1: true
---

A leaflet plugin for a configurable search bar component with autocomplete on all existing pins on the map.