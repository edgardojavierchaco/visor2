---
name: Leaflet.AnimatedSearchBox
category: search-popups
repo: https://github.com/luka1199/Leaflet.AnimatedSearchBox
author: Luka Steinbach
author-url: https://github.com/luka1199/
demo: https://luka1199.github.io/Leaflet.AnimatedSearchBox/examples/example_fuse.html
compatible-v0:
compatible-v1: true
---

A simple Leaflet plugin that provides a collapsible search box.
