---
name: Leaflet-gplaces-autocomplete
category: search-popups
repo: https://github.com/Twista/leaflet-google-places-autocomplete
author: Michal Haták
author-url: https://github.com/Twista
demo: 
compatible-v0:
compatible-v1: true
---

Add google places search into map
