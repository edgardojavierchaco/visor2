---
name: Leaflet GeoJSON Encoded
category: basemap-formats
repo: https://github.com/geobricks/Leaflet.GeoJSON.Encoded
author: Geobricks
author-url: https://github.com/geobricks/
demo: 
compatible-v0:
compatible-v1: true
---

Extends the L.GeoJSON layer using Google polyline encoding algorithm, allowing an optimized data transfer.
