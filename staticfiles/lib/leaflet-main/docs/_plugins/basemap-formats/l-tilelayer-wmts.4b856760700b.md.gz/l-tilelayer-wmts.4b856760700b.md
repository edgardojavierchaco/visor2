---
name: L.TileLayer.WMTS
category: basemap-formats
repo: https://github.com/alcalin/L.TileLayer.WMTS
author: Alexandru Calin
author-url: https://github.com/alcalin
demo: https://alcalin.github.io/L.TileLayer.WMTS/example.html
compatible-v0:
compatible-v1: true
---

A simple WMTS Tile Layer plugin for Leaflet.
