---
name: Leaflet.NonTiledLayer.WCS
category: basemap-formats
repo: https://github.com/stuartmatthews/Leaflet.NonTiledLayer.WCS
author: Stuart Matthews
author-url: https://github.com/stuartmatthews
demo: https://stuartmatthews.github.io/Leaflet.NonTiledLayer.WCS/
compatible-v0:
compatible-v1: true
---

Display raster data from Web Coverage Services.  Rasters can be styled and queried in the client.
