---
name: Leaflet-Select-Polygons
category: area-overlay-selection
repo: https://github.com/olanaso/Leaflet-Select-Polygons
author: Erick S Escalante Olano
author-url: https://github.com/olanaso
demo: https://olanaso.github.io/Leaflet-Select-Polygons/
compatible-v0:
compatible-v1: true
---

Leaflet-Select-Polygons allows the selection of several polygons and also adjusts the base map view.
