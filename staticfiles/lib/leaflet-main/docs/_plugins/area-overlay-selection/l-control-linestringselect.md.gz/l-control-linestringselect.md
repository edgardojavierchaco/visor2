---
name: L.Control.LineStringSelect
category: area-overlay-selection
repo: https://github.com/w8r/L.Control.LineStringSelect
author: Alexander Milevski
author-url: https://github.com/w8r
demo: https://milevski.co/L.Control.LineStringSelect/examples/
compatible-v0:
compatible-v1: true
---

Fast LineString(polyline) partial selection tool: select a stretch between two points in a complex path.
