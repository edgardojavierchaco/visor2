---
name: Leaflet-Area-Selection
category: area-overlay-selection
repo: https://github.com/bopen/leaflet-area-selection
author: B-Open
author-url: https://www.bopen.eu/
demo: https://bopen.github.io/leaflet-area-selection/
compatible-v0:
compatible-v1: true
---

leaflet-area-selection allows to easily select a polygonal area on the map.
