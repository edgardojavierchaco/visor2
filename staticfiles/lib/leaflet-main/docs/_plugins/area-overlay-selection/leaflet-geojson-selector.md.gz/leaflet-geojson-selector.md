---
name: Leaflet GeoJSON Selector
category: area-overlay-selection
repo: https://github.com/stefanocudini/leaflet-geojson-selector
author: Stefano Cudini
author-url: https://opengeo.tech/
demo: https://opengeo.tech/maps/leaflet-geojson-selector/
compatible-v0:
compatible-v1: true
---

Leaflet Control for selection from GeoJSON feature in an interactive list and map.
