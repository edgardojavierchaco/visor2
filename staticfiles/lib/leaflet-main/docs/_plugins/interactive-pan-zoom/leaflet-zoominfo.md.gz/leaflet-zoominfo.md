---
name: Leaflet.zoominfo
category: interactive-pan-zoom
repo: https://github.com/flaviocarmo/Leaflet.zoominfo/
author: Flávio Carmo
author-url: https://github.com/flaviocarmo
demo: https://flaviocarmo.github.io/Leaflet.zoominfo/examples/
compatible-v0:
compatible-v1: true
---

A zoom control which displays the current zoom level.
