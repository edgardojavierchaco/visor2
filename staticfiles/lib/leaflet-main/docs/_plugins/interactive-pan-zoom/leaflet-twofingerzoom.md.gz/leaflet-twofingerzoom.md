---
name: Leaflet.twofingerZoom
category: interactive-pan-zoom
repo: https://github.com/aratcliffe/Leaflet.twofingerzoom
author: Adam Ratcliffe
author-url: https://github.com/aratcliffe/
demo: 
compatible-v0:
compatible-v1: true
---

Interaction handler for touch devices enabling zooming out with a two finger tap.
