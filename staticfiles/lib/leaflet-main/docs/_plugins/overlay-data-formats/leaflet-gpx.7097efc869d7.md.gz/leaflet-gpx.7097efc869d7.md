---
name: Leaflet GPX
category: overlay-data-formats
repo: https://github.com/mpetazzoni/leaflet-gpx
author: Maxime Petazzoni
author-url: https://github.com/mpetazzoni/
demo: https://mpetazzoni.github.io/leaflet-gpx/
compatible-v0:
compatible-v1: true
---

GPX layer, targeted at sporting activities by providing access to information such as distance, moving time, pace, elevation, heart rate, etc.
