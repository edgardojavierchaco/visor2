---
name: Leaflet-GeoPackage
category: overlay-data-formats
repo: https://github.com/ngageoint/leaflet-geopackage
author: Daniel Barela
author-url: https://github.com/danielbarela
demo: https://ngageoint.github.io/leaflet-geopackage/examples/index.html
compatible-v0:
compatible-v1: true
---

Load <a href="http://www.geopackage.org/">GeoPackage</a> Tile and Feature Layers.
