---
name: Leaflet LayerJSON
category: overlay-data-formats
repo: https://github.com/stefanocudini/leaflet-layerJSON
author: Stefano Cudini
author-url: https://opengeo.tech/
demo: https://opengeo.tech/maps/leaflet-layerjson/
compatible-v0:
compatible-v1: true
---

Simple way for transform any JSON data source in a Leaflet Layer, load JSON data in layer and minimize remote requests with caching system.
