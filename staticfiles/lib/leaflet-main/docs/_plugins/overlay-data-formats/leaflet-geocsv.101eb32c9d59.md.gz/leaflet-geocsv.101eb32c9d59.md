---
name: Leaflet.geoCSV
category: overlay-data-formats
repo: https://github.com/joker-x/Leaflet.geoCSV
author: Iván Eixarch
author-url: https://github.com/joker-x
demo: 
compatible-v0:
compatible-v1: true
---

Leaflet plugin for loading a CSV file as geoJSON layer.
