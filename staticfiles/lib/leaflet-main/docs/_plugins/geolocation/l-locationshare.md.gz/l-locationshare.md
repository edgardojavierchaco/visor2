---
name: L.LocationShare
category: geolocation
repo: https://github.com/CliffCloud/Leaflet.LocationShare
author: atstp
author-url: https://github.com/atstp
demo: https://cliffcloud.github.io/Leaflet.LocationShare/
compatible-v0: true
compatible-v1: false
---

Allow users to send and receive a marker with a message.
