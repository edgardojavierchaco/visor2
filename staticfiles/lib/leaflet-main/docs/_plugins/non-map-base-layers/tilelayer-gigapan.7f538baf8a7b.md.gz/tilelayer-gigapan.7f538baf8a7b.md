---
name: TileLayer.Gigapan
category: non-map-base-layers
repo: https://github.com/namrehs/Leaflet.Gigapan
author: Dan Sherman
author-url: https://github.com/namrehs
demo: 
compatible-v0:
compatible-v1: true
---

A TileLayer for Gigapan images.
