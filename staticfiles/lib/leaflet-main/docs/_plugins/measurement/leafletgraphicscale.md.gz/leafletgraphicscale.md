---
name: leaflet-graphicscale
category: measurement
repo: https://github.com/kalisio/leaflet-graphicscale
author: Kalisio contributors, Erik Escoffier
author-url: https://github.com/kalisio
demo: https://kalisio.github.io/leaflet-graphicscale
compatible-v0:
compatible-v1: true
---

Configurable and animated graphic scale control.
