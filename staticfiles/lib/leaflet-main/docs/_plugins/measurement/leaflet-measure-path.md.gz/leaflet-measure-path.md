---
name: Leaflet Measure Path
category: measurement
repo: https://github.com/ProminentEdge/leaflet-measure-path
author: Per Liedman
author-url: https://github.com/perliedman
demo: https://prominentedge.com/leaflet-measure-path/
compatible-v0:
compatible-v1: true
---

Show measurements on paths; polylines, polygons and circles currently supported.
