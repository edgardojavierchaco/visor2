---
name: Leaflet.MeasurePolygon
category: measurement
repo: https://github.com/olanaso/Leaflet.MeasurePolygon
author: Erick S. Escalante Olano
author-url: https://github.com/olanaso
demo: https://olanaso.github.io/Leaflet.MeasurePolygon
compatible-v0:
compatible-v1: true
---

MeasurePolygon allows you to calculate the area and perimeter of a polygon when drawing, very visible and didactics.
