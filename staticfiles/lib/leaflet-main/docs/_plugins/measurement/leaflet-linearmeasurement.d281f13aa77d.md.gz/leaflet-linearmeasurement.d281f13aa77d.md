---
name: Leaflet.LinearMeasurement
category: measurement
repo: https://github.com/NLTGit/Leaflet.LinearMeasurement
author: New Light Technologies
author-url: https://newlighttechnologies.com/
demo: https://nltgit.github.io/Leaflet.LinearMeasurement/
compatible-v0:
compatible-v1: true
---

Leaflet Linear Measurement plugin that creates polylines with incremental measures along the path.
