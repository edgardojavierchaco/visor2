---
name: Leaflet.QgsMeasure
category: measurement
repo: https://github.com/gabriel-russo/Leaflet.QgsMeasure
author: Gabriel Russo
author-url: https://github.com/gabriel-russo/
demo: https://gabriel-russo.github.io/Leaflet.QgsMeasure/example/
compatible-v0: false
compatible-v1: true
---

Leaflet control to measure segment distances on the map like Qgis Ruler.
