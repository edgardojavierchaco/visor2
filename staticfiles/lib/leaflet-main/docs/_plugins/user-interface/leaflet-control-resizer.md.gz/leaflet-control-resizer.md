---
name: Leaflet.Control.Resizer
category: user-interface
repo: https://github.com/jjimenezshaw/Leaflet.Control.Resizer
author: Javier Jimenez Shaw
author-url: https://github.com/jjimenezshaw/
demo: https://jjimenezshaw.github.io/Leaflet.Control.Resizer/examples/basic.html
compatible-v0:
compatible-v1: true
---

Control to resize your map on the right or bottom side.
