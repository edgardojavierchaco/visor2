---
name: Leaflet.GeojsonLayerSwitcher
category: user-interface
repo: https://github.com/easymountain/Leaflet.GeojsonLayerSwitcher
author: Easy-Mountain
author-url: https://github.com/easymountain
demo: https://github.com/easymountain/Leaflet.GeojsonLayerSwitcher#demo
compatible-v0:
compatible-v1: true
---

Allows to navigate between GeoJSON layers, select some, and return selection.
