---
name: Leaflet.Notifications
category: user-interface
repo: https://gitlab.com/manuel.richter95/leaflet.notifications
author: Manuel Richter
author-url: https://gitlab.com/manuel.richter95
demo: http://leaflet-notifications.manuel-ri.de/
compatible-v0:
compatible-v1: true
---

Spawn toast notifications inside your map
