---
name: leaflet-multicontrol
category: user-interface
repo: https://github.com/clavijojuan/L.multiControl
author: Juan Camilo Clavijo Sandoval
author-url: https://github.com/clavijojuan
demo: https://serene-heyrovsky-2fb229.netlify.app/
compatible-v0: false
compatible-v1: true
---

Leaflet plugin to implements layers control with multiple functionality such as opacity, color, bringToFront, bringToBack, zoomToLayer, delete and legend.
