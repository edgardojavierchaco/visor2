---
name: L.EasyButton
category: user-interface
repo: https://github.com/CliffCloud/Leaflet.EasyButton
author: atstp
author-url: https://github.com/atstp
demo: https://cliffcloud.github.io/Leaflet.EasyButton/
compatible-v0:
compatible-v1: true
---

In one line, add a Font Awesome control button with attached click events.
