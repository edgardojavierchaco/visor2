---
name: leaflet-sidepanel
category: user-interface
repo: https://github.com/maxwell-ilai/Leaflet.SidePanel
author: Maxwell Ilai
author-url: https://github.com/maxwell-ilai
demo: https://maxwell-ilai.github.io/Leaflet.SidePanel/examples/
compatible-v0: false
compatible-v1: true
---

Sidepanel with tabs. Keep it short and check out the [plugin guide](https://github.com/maxwell-ilai/Leaflet.SidePanel/blob/main/README.md).
