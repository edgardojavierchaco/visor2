---
name: Leaflet.BootstrapZoom
category: user-interface
repo: https://github.com/MAD-GooZe/Leaflet.BootstrapZoom
author: Alexey Gusev
author-url: https://github.com/MAD-GooZe
demo: https://mad-gooze.github.io/Leaflet.BootstrapZoom/
compatible-v0:
compatible-v1: true
---

Overrides default zoom control buttons with Twitter Bootstrap styled ones
