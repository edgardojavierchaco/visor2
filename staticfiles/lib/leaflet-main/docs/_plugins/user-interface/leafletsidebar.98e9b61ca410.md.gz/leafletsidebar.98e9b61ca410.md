---
name: leaflet-sidebar
category: user-interface
repo: https://github.com/turbo87/leaflet-sidebar/
author: Tobias Bieniek
author-url: https://github.com/turbo87/
demo: http://turbo87.github.io/leaflet-sidebar/examples/
compatible-v0:
compatible-v1: true
---

A responsive sidebar plugin.
