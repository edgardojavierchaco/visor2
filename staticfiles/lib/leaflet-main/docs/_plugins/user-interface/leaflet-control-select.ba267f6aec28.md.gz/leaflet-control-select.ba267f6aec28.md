---
name: Leaflet.Control.Select
category: user-interface
repo: https://github.com/adammertel/Leaflet.Control.Select
author: Adam Mertel
author-url: https://github.com/adammertel
demo: https://adammertel.github.io/Leaflet.Control.Select/
compatible-v0:
compatible-v1: true
---

Customisable menu-style control.
