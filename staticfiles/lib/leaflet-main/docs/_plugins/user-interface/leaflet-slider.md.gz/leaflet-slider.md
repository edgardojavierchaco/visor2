---
name: Leaflet.Slider
category: user-interface
repo: https://github.com/Eclipse1979/leaflet-slider
author: EPP
author-url: https://github.com/Eclipse1979
demo: https://eclipse1979.github.io/leaflet.slider/example/leaflet-slider.html
compatible-v0:
compatible-v1: true
---

Adds a <code>&lt;input type="range"&gt;</code> slider that calls a function every time its input is changed.
