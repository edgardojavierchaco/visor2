---
name: Leaflet.Messagebox
category: user-interface
repo: https://github.com/tinuzz/leaflet-messagebox
author: Martijn Grendelman
author-url: https://github.com/tinuzz/
demo: https://www.grendelman.net/leaflet/
compatible-v0:
compatible-v1: true
---

Display a temporary text message on a map.
