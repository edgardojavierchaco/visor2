---
name: leaflet-control-window
category: user-interface
repo: https://github.com/mapshakers/leaflet-control-window
author: mapshakers
author-url: https://github.com/mapshakers
demo: http://mapshakers.com/projects/leaflet-control-window/
compatible-v0:
compatible-v1: true
---

Creates modal/modeless, draggable, responsive, customisable window in your map.
