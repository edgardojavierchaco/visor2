---
name: Leaflet.Spin
category: user-interface
repo: https://github.com/makinacorpus/Leaflet.Spin
author: Mathieu Leplatre
author-url: https://github.com/leplatrem
demo: https://makinacorpus.github.io/Leaflet.Spin/
compatible-v0:
compatible-v1: true
---

Shows a nice spinner on the map using <a href="https://github.com/fgnass/spin.js/">Spin.js</a>,			for asynchronous data load, like with <a href="https://github.com/calvinmetcalf/leaflet-ajax">Leaflet Ajax</a>.
