---
name: Leaflet.Dialog
category: user-interface
repo: https://github.com/NBTSolutions/Leaflet.Dialog
author: NBT Solutions
author-url: https://github.com/NBTSolutions
demo: https://nbtsolutions.github.io/Leaflet.Dialog/
compatible-v0:
compatible-v1: true
---

A simple resizable, movable, customizable dialog box.
