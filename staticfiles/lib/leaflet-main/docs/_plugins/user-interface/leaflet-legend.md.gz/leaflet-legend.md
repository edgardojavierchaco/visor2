---
name: Leaflet.Legend
category: user-interface
repo: https://github.com/ptma/Leaflet.Legend
author: JJ Jin
author-url: https://github.com/ptma
demo: https://ptma.github.io/Leaflet.Legend/examples/legend.html
compatible-v0:
compatible-v1: true
---

Display legend symbols and toggle overlays.
