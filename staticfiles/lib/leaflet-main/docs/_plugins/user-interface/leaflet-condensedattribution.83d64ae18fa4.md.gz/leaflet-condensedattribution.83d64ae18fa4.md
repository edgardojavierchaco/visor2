---
name: Leaflet.CondensedAttribution
category: user-interface
repo: https://github.com/targomo/Leaflet.CondensedAttribution
author: Targomo GmbH
author-url: https://www.targomo.com/
demo: https://route360.github.io/Leaflet.CondensedAttribution/
compatible-v0:
compatible-v1: true
---

An attribution plugin that makes long attributes visible on hover
