---
name: Leaflet.SlideMenu
category: user-interface
repo: https://github.com/unbam/Leaflet.SlideMenu
author: Masashi Takeshita
author-url: https://github.com/unbam
demo: http://unbam.github.io/Leaflet.SlideMenu/
compatible-v0:
compatible-v1: true
---

A simple slide menu for Leaflet.
