---
name: Leaflet Weather
category: user-interface
repo: https://github.com/oskosk/Leaflet.Weather
author: Osk
author-url: https://github.com/oskosk
demo: https://oskosk.github.io/Leaflet.Weather/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin for adding a weather widget to the map using OpenWeatherMap API.
