---
name: L.cascadeButtons
category: user-interface
repo: https://github.com/clavijojuan/L.cascadeButtons
author: clavijojuan
author-url: https://github.com/clavijojuan
demo: https://vibrant-perlman-43d7a4.netlify.app/
compatible-v0:
compatible-v1: true
---

A leaflet plugin to create cascade buttons.
