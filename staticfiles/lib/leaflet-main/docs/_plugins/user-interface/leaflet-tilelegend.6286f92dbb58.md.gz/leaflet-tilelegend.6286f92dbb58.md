---
name: Leaflet.TileLegend
category: user-interface
repo: https://github.com/yohanboniface/Leaflet.TileLegend
author: Yohan Boniface
author-url: https://yohanboniface.me/
demo: http://map.hotosm.org
compatible-v0:
compatible-v1: true
---

Create illustrated and interactive legends for your background layers.
