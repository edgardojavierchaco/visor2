---
name: Leaflet.contextmenu
category: user-interface
repo: https://github.com/aratcliffe/Leaflet.contextmenu
author: Adam Ratcliffe
author-url: https://github.com/aratcliffe/
demo: https://aratcliffe.github.io/Leaflet.contextmenu/examples/index.html
compatible-v0:
compatible-v1: true
---

A context menu for Leaflet.
