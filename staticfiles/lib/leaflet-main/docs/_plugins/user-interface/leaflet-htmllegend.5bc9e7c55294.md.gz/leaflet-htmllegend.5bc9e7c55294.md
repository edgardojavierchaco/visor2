---
name: Leaflet.HtmlLegend
category: user-interface
repo: https://github.com/consbio/Leaflet.HtmlLegend
author: Kaveh Karimi
author-url: https://github.com/ka7eh
demo: https://consbio.github.io/Leaflet.HtmlLegend/
compatible-v0:
compatible-v1: true
---

A simple Leaflet plugin for creating legends using HTML elements.
