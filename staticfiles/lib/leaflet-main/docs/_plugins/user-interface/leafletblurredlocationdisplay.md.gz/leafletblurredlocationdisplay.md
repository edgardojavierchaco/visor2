---
name: leaflet-blurred-location-display
category: user-interface
repo: https://github.com/publiclab/leaflet-blurred-location-display
author: Public Lab
author-url: https://github.com/publiclab
demo: https://publiclab.github.io/leaflet-blurred-location-display/examples/HumanReadableBlurring.html
compatible-v0:
compatible-v1: true
---

Cleverly displays "blurred" locations using color-coded heatmap and color-coded markers while fetching data from remote API.
