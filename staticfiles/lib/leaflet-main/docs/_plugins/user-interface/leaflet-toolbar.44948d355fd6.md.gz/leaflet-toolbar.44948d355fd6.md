---
name: Leaflet.toolbar
category: user-interface
repo: https://github.com/Leaflet/Leaflet.toolbar
author: Justin Manley
author-url: https://github.com/manleyjster
demo: https://leaflet.github.io/Leaflet.toolbar/examples/popup.html
compatible-v0:
compatible-v1: true
---

Flexible, extensible toolbars for Leaflet maps.
