---
name: Leaflet.Signposts
category: user-interface
repo: https://github.com/williamlow/Leaflet.Signposts
author: William Low
author-url: https://github.com/williamlow
demo: https://williamlow.github.io/leaflet-signpost/demo.html
compatible-v0:
compatible-v1: true
---

Guides users to points outside the current map view with directional arrows and a count of points in each given direction.
