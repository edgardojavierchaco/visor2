---
name: Leaflet ResizableControl
category: user-interface
repo: https://github.com/dalbrx/Leaflet.ResizableControl
author: David Albrecht
author-url: https://github.com/dalbrx
demo: https://dalbrx.github.io/Leaflet.ResizableControl/
compatible-v0:
compatible-v1: true
---

A Leaflet plugin to add a resizable and scrollable control to the map.
