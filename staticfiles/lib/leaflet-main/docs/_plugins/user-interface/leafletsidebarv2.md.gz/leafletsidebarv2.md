---
name: leaflet-sidebar-v2
category: user-interface
repo: https://github.com/noerw/leaflet-sidebar-v2
author: Norwin Roosen
author-url: https://github.com/noerw/
demo: https://noerw.github.io/leaflet-sidebar-v2/examples/
compatible-v0: true
compatible-v1: true
---

A responsive, tabbed sidebar with HTML &amp; JS API. Compatible with old (0.7) and current leaflet.
