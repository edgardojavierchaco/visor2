---
name: Leaflet.CountrySelect
category: user-interface
repo: https://github.com/ahalota/Leaflet.CountrySelect/
author: Anika Halota
author-url: https://github.com/ahalota/
demo: http://ahalota.github.io/Leaflet.CountrySelect/demo.html
compatible-v0:
compatible-v1: true
---

Control with menu of all countries, and an event listener that returns the selected country as a GeoJSON feature.
