---
name: sidebar-v2
category: user-interface
repo: https://github.com/turbo87/sidebar-v2/
author: Tobias Bieniek
author-url: https://github.com/turbo87/
demo: https://turbo87.github.io/sidebar-v2/examples/index.html
compatible-v0:
compatible-v1: true
---

Another responsive sidebar plugin. This time with tabs!
