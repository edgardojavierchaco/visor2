---
name: Leaflet.CoordinatedImagePreview
category: user-interface
repo: https://github.com/utahemre/Leaflet.CoordinatedImagePreview
author: Yunus Emre Özkaya
author-url: https://github.com/utahemre
demo: https://utahemre.github.io/coordinatedimagepreviewdemo.html
compatible-v0:
compatible-v1: true
---

Displays coordinated images in map bounds.
