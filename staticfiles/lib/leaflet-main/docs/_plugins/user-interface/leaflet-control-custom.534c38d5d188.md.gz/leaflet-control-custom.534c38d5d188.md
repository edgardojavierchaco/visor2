---
name: Leaflet.Control.Custom
category: user-interface
repo: https://github.com/yigityuce/Leaflet.Control.Custom
author: Yiğit Yüce
author-url: https://github.com/yigityuce
demo: https://yigityuce.github.io/Leaflet.Control.Custom/examples/index.html
compatible-v0:
compatible-v1: true
---

Fully customizable Leaflet control panel with HTML element.
