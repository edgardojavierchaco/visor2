---
name: L.Credits
category: user-interface
repo: https://github.com/GreenInfo-Network/Leaflet-Control-Credits
author: Greg Allensworth
author-url: https://github.com/gregallensworth/
demo: https://greeninfo-network.github.io/Leaflet-Control-Credits/
compatible-v0:
compatible-v1: true
---

A simple, attractive, interactive control to put your logo and link in the corner of your map.
