---
name: leaflet-blurred-location
category: user-interface
repo: https://github.com/publiclab/leaflet-blurred-location/
author: Public Lab
author-url: https://github.com/publiclab
demo: https://publiclab.github.io/leaflet-blurred-location/examples/
compatible-v0:
compatible-v1: true
---

A Leaflet-based interface for selecting a "blurred" or low-resolution location, to preserve privacy.
