---
name: Leaflet.StyledLayerControl
category: layer-switching-controls
repo: https://github.com/davicustodio/Leaflet.StyledLayerControl
author: Davi Custodio
author-url: https://github.com/davicustodio
demo: http://davicustodio.github.io/Leaflet.StyledLayerControl/examples/example1.html
compatible-v0:
compatible-v1: true
---

A Leaflet plugin that implements the management and control of layers by organization into categories or groups.
