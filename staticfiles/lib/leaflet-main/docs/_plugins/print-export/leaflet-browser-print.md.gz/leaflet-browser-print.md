---
name: leaflet.browser.print
category: print-export
repo: https://github.com/Igor-Vladyka/leaflet.browser.print
author: Igor Vladyka
author-url: https://github.com/Igor-Vladyka
demo: https://igor-vladyka.github.io/leaflet.browser.print/
compatible-v0:
compatible-v1: true
---

Allows users to print full page map directly from the browser.
