---
name: leaflet-route-print
category: print-export
repo: https://github.com/hersle/leaflet-route-print
author: Herman Sletmoen
author-url: https://github.com/hersle
demo: https://hersle.github.io/leaflet-route-print/
compatible-v0:
compatible-v1: true
---

Automatic PDF printing of routes (i.e. polylines) with custom scale, paper size and margin by covering the route with a sequence of identical rectangles.
