---
name: JSF2Leaf
category: frameworks-build-systems
repo: https://github.com/themrleon/JSF2Leaf
author: Leonardo Ciocari
author-url: https://github.com/themrleon
demo: 
compatible-v0:
compatible-v1: true
---

A JavaServer Faces wrapper for Leaflet.
