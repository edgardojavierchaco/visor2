---
name: ember-leaflet
category: frameworks-build-systems
repo: https://miguelcobain.github.io/ember-leaflet/
author: Miguel Andrade
author-url: https://github.com/miguelcobain
demo: 
compatible-v0:
compatible-v1: true
---

Easy and declarative mapping for <a href="https://emberjs.com/">Ember.js</a> using Leaflet.
