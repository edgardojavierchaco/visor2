---
name: Leaflet.jsf
category: frameworks-build-systems
repo: https://bitbucket.org/terrayazilim/leaflet.jsf
author: Terra SI LLC.
author-url: http://terrayazilim.com.tr/
demo: 
compatible-v0:
compatible-v1: true
---

Comprehensive Java Server Faces(JSF) Component/Wrapper for Leaflet.
