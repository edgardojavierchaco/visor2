---
name: Leaflet.a11y
category: frameworks-build-systems
repo: https://github.com/nfreear/leaflet.a11y
author: Nick Freear
author-url: https://nick.freear.org.uk/
demo: https://nfreear.github.io/leaflet.a11y/
compatible-v0:
compatible-v1: true
---

An accessibility and localization/translation plugin for Leaflet.
