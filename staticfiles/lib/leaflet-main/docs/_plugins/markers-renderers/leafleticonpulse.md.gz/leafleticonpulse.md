---
name: leaflet-icon-pulse
category: markers-renderers
repo: https://github.com/mapshakers/leaflet-icon-pulse
author: mapshakers
author-url: https://github.com/mapshakers
demo: http://mapshakers.com/projects/leaflet-pulse-icon/
compatible-v0:
compatible-v1: true
---

Renders pulsing icon using CSS. It can be used for location marker.
