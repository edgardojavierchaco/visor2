---
name: Leaflet.RoughCanvas
category: markers-renderers
repo: https://github.com/zhuang-hao-ming/Leaflet.RoughCanvas
author: haoming
author-url: https://github.com/zhuang-hao-ming/
demo: https://zhuang-hao-ming.github.io/Leaflet.RoughCanvas/
compatible-v0:
compatible-v1: true
---

Leaflet.RoughCanvas renders hand-drawn, sketch style vector map (polyline, polygon, geojson).
