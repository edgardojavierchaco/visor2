---
name: Leaflet.Marker.Highlight
category: markers-renderers
repo: https://github.com/brandonxiang/leaflet.marker.highlight
author: Brandon Xiang
author-url: https://github.com/brandonxiang
demo: https://brandonxiang.github.io/leaflet.marker.highlight/examples/
compatible-v0:
compatible-v1: true
---

Adding highlight performance for L.marker.
