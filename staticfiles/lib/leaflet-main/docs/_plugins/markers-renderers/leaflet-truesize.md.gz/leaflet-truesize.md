---
name: Leaflet Truesize
category: markers-renderers
repo: https://wbkd.github.io/leaflet-truesize/
author: webkid
author-url: https://webkid.io/
demo: https://wbkd.github.io/leaflet-truesize/
compatible-v0:
compatible-v1: true
---

A plugin for creating projection aware draggable polygons and polylines.
