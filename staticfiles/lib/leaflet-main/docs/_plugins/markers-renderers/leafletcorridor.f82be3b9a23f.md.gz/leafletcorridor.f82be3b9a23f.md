---
name: leaflet-corridor
category: markers-renderers
repo: https://github.com/mikhailshilkov/leaflet-corridor
author: Mikhail Shilkov
author-url: https://github.com/mikhailshilkov
demo: https://mikhail.io/demos/leaflet-corridor/
compatible-v0:
compatible-v1: true
---

Renders a polyline with width fixed in meters, not in pixels. Adjusts width depending on zoom level.
