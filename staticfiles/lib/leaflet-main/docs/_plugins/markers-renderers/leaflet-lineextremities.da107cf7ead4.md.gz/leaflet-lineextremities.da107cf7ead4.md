---
name: Leaflet.LineExtremities
category: markers-renderers
repo: https://github.com/makinacorpus/Leaflet.LineExtremities
author: Frédéric Bonifas
author-url: https://github.com/fredericbonifas
demo: https://makinacorpus.github.io/Leaflet.LineExtremities/
compatible-v0:
compatible-v1: true
---

Show symbols at the extremities of polylines, using SVG markers.
