---
name: Leaflet.GLMarkers
category: markers-renderers
repo: https://gitlab.com/IvanSanchez/Leaflet.GLMarkers
author: Iván Sánchez Ortega
author-url: https://gitlab.com/IvanSanchez
demo: http://https//ivansanchez.gitlab.io/Leaflet.GLMarkers/demo/repl.html
compatible-v0:
compatible-v1: true
---

Display thousands of markers with custom WebGL shaders, optionally animated.
