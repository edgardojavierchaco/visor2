---
name: leaflet-layervisibility
category: markers-renderers
repo: https://github.com/phloose/leaflet-layervisibility
author: Philipp Loose
author-url: https://github.com/phloose/
demo: https://phloose.github.io/leaflet-layervisibility/
compatible-v0:
compatible-v1: true
---

Extends L.Layer and L.LayerGroup with methods to hide/show layers without removing/re-adding them.
