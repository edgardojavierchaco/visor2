---
name: Leaflet-polygon-fillPattern-canvas
category: markers-renderers
repo: https://github.com/bgx1012/leaflet-polygon-fillPattern-canvas
author: bgx1012
author-url: https://github.com/bgx1012
demo: 
compatible-v0: false
compatible-v1: true
---

Extend the Polygon Object to fill canvas element with an image pattern. Performance is better than svg rendering. Can improve the rendering performance of big data.
