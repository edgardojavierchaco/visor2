---
name: leaflet-simplestyle
category: markers-renderers
repo: https://github.com/rowanwins/leaflet-simplestyle
author: Rowan Winsemius
author-url: https://github.com/rowanwins/
demo: https://rowanwins.github.io/leaflet-simplestyle/example/basic.html
compatible-v0:
compatible-v1: true
---

Extends L.geoJSON to support the <a href="https://github.com/mapbox/simplestyle-spec">simple style</a> spec.
