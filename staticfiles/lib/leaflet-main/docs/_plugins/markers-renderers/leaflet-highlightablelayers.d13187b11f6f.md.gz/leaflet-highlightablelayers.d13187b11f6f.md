---
name: Leaflet.HighlightableLayers
category: markers-renderers
repo: https://github.com/FacilMap/Leaflet.HighlightableLayers
author: Candid Dauth
author-url: https://github.com/cdauth/
demo: https://unpkg.com/leaflet-highlightable-layers/example.html
compatible-v0:
compatible-v1: true
---

Highlight Leaflet lines and polygons by adding a border and raising them above others. Add a transparent border to increase the tolerance for mouse/touch interactions.
