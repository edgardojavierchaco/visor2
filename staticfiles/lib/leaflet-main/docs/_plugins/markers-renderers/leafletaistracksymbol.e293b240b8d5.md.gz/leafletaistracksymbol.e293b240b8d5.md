---
name: leaflet-ais-tracksymbol
category: markers-renderers
repo: https://github.com/PowerPan/leaflet-ais-tracksymbol
author: Johannes Rudolph
author-url: https://github.com/powerpan
demo: 
compatible-v0:
compatible-v1: true
---

AIS Extension for leaflet-tracksymbol It displays AIS Contacts on the Map.
