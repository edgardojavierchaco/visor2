---
name: Leaflet.CenterMarker
category: markers-renderers
repo: https://github.com/heyman/leaflet-centermarker
author: Jonatan Heyman
author-url: https://heyman.info/
demo: 
compatible-v0:
compatible-v1: true
---

Marker that is kept fixed to the center of the map when the map is panned by dragging.			Can be seen in action on <a href="https://whatismyaddress.net/">What is my address?</a>
