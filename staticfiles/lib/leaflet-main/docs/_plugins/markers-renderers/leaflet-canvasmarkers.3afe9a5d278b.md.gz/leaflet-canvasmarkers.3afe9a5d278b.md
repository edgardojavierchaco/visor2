---
name: Leaflet.Canvas-Markers
category: markers-renderers
repo: https://github.com/eJuke/Leaflet.Canvas-Markers
author: Evgeniy Voynov
author-url: https://github.com/eJuke
demo: https://ejuke.github.io/Leaflet.Canvas-Markers/examples/index.html
compatible-v0:
compatible-v1: true
---

Displays markers on canvas instead of DOM.
