---
name: Leaflet.LabelTextCollision
category: markers-renderers
repo: https://github.com/yakitoritabetai/Leaflet.LabelTextCollision
author: Kenta Hakoishi
author-url: https://github.com/yakitoritabetai
demo: https://yakitoritabetai.github.io/Leaflet.LabelTextCollision/
compatible-v0:
compatible-v1: true
---

Displays labels on paths (polylines, polygons, circles) avoiding label collision.
