---
name: Leaflet-SVGIcon
category: markers-renderers
repo: https://github.com/iatkin/leaflet-svgicon
author: Ilya Atkin
author-url: https://github.com/iatkin
demo: http://iatkin.github.io/leaflet-svgicon/
compatible-v0:
compatible-v1: true
---

A simple and customizable SVG icon with no external dependencies. Also included is a convenience Marker class and two example subclasses.
