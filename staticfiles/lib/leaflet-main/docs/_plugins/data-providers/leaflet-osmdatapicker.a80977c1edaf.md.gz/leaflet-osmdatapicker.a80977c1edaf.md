---
name: leaflet.osmdatapicker
category: data-providers
repo: https://github.com/amrHH/Leaflet.OSMDataPicker
author: Amr Hamadeh
author-url: https://github.com/amrHH
demo: https://amrhh.github.io/Leaflet.OSMDataPicker/
compatible-v0:
compatible-v1: true
---

Simple and fast way to get any Open Street Map (OSM) data in your drawn zone. Data from [overpass-turbo](https://overpass-turbo.eu/).
