---
name: maplibre-gl-leaflet
category: vector-tiles
repo: https://github.com/maplibre/maplibre-gl-leaflet
author: MapLibre
author-url: https://www.maplibre.org/
demo:
compatible-v0: false
compatible-v1: true
---

Loads a [maplibre-gl-js](https://maplibre.org/projects/maplibre-gl-js/) map as a Leaflet layer
