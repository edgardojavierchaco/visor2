---
name: leaflet-geojson-vt
category: vector-tiles
repo: https://github.com/iamtekson/leaflet-geojson-vt
author: Tek Kshetri
author-url: https://github.com/iamtekson
demo: https://iamtekson.github.io/leaflet-geojson-vt/demo/
compatible-v0:
compatible-v1: true
---

Displaying the vector tiles of GeoJSON data on the fly on leaflet
