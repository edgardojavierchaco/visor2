---
name: Leaflet.MapboxVectorTile
category: vector-tiles
repo: https://github.com/SpatialServer/Leaflet.MapboxVectorTile
author: SpatialDev
author-url: https://www.spatialdev.com/
demo: http://spatialserver.github.io/Leaflet.MapboxVectorTile/examples/confetti.html
compatible-v0: true
compatible-v1: false
---

A Leaflet Plugin that renders Mapbox Vector Tiles on canvas. Compatible with Leaflet 0.7.x only.
