---
name: protomaps-leaflet
category: vector-tiles
repo: https://github.com/protomaps/protomaps-leaflet
author: Protomaps
author-url: https://protomaps.com/
demo: https://protomaps.github.io/protomaps-leaflet/examples/leaflet.html
compatible-v0: false
compatible-v1: true
---

Lightweight vector map rendering + labeling and symbology for Leaflet (supporting pmtiles and pbf format)
