---
name: leaflet.fullscreen
category: fullscreen-controls
repo: https://github.com/brunob/leaflet.fullscreen
author: Bruno B
author-url: https://github.com/brunob/
demo: https://brunob.github.io/leaflet.fullscreen/
compatible-v0:
compatible-v1: true
---

Another fullscreen button control but for modern browsers, using HTML Fullscreen API.
