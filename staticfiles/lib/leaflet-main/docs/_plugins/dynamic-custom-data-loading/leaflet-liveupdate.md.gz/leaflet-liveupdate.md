---
name: Leaflet.Liveupdate
category: dynamic-custom-data-loading
repo: https://github.com/tinuzz/leaflet-liveupdate
author: Martijn Grendelman
author-url: https://github.com/tinuzz/
demo: https://www.grendelman.net/leaflet/
compatible-v0:
compatible-v1: true
---

Periodically ('live') update something on a map.
