---
name: Leaflet Realtime
category: dynamic-custom-data-loading
repo: https://github.com/perliedman/leaflet-realtime
author: Per Liedman
author-url: https://github.com/perliedman/
demo: 
compatible-v0:
compatible-v1: true
---

Put realtime data on a Leaflet map: live tracking GPS units, sensor data or just about anything.
