---
name: Maptiks
category: 3rd-party-integration
repo: https://maptiks.com/
author: Sparkgeo
author-url: https://sparkgeo.com/
demo: 
compatible-v0:
compatible-v1: true
---

Analytics platform for web maps. Track map activities, layer load times, marker clicks, and more!
