---
name: Yii2-locator
category: 3rd-party-integration
repo: https://github.com/sjaakp/yii2-locator
author: Sjaak Priester
author-url: https://github.com/sjaakp
demo: https://sjaakpriester.nl/software/locator
compatible-v0:
compatible-v1: true
---

Leaflet widget for <a href="https://www.yiiframework.com/">Yii2 PHP Framework</a>. Geographical data stored in an ActiveRecord can be displayed and updated on interactive maps.
