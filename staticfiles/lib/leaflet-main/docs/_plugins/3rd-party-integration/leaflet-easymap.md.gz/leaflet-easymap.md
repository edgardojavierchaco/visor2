---
name: Leaflet Easymap
category: 3rd-party-integration
repo: https://github.com/Lapizistik/leaflet-easymap
author: Klaus Stein
author-url: https://github.com/Lapizistik
demo: https://lapizistik.github.io/leaflet-easymap/
compatible-v0:
compatible-v1: true
---

Include a map in your HTML page without one line of programming. A data-driven Javascript module.
