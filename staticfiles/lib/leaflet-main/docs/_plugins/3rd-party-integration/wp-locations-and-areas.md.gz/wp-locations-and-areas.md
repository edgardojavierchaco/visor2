---
name: Locations and Areas
category: 3rd-party-integration
repo: https://wordpress.org/plugins/locations-and-areas/
author: 100plugins
author-url: https://www.locations-and-areas.com/?ref=leafletjs.com
demo: 
compatible-v0:
compatible-v1: true
---

WordPress plugin to showcase widely distributed locations on a single map with additional navigation tabs for regions. The map is based on Leaflet JS and offers you several free map styles. Gutenberg Block included.
