---
name: Leaflet.DonutCluster
category: clustering-decluttering
repo: https://github.com/kalisio/Leaflet.DonutCluster
author: Kalisio contributors
author-url: https://github.com/kalisio
demo: https://jsfiddle.net/b43c1xkf/1/embedded/result,html
compatible-v0:
compatible-v1: true
---

A lightweight standalone [Leaflet](https://leafletjs.com) plugin to display donut charts instead of circles in map when using [Leaflet marker cluster](https://github.com/Leaflet/Leaflet.markercluster).
