---
name: Overlapping Marker Spiderfier
category: clustering-decluttering
repo: https://github.com/jawj/OverlappingMarkerSpiderfier-Leaflet
author: George MacKerron
author-url: http://mackerron.com/
demo: http://jawj.github.io/OverlappingMarkerSpiderfier-Leaflet/demo.html
compatible-v0:
compatible-v1: true
---

Deals with overlapping markers in a Google Earth-inspired way by gracefully springing them apart on click.
