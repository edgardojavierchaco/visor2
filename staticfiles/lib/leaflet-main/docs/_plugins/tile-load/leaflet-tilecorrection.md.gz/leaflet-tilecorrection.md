---
name: Leaflet.TileCorrection
category: tile-load
repo: https://github.com/z632896862/Leaflet.TileCorrection
author: Allart Kooiman
author-url: https://github.com/z632896862
demo: 
compatible-v0:
compatible-v1: true
---

Allow tiles to be loaded in an different crs from map's and start at a custom zoom.
