---
name: TileLayer.Cordova
category: tile-load
repo: https://github.com/gregallensworth/L.TileLayer.Cordova
author: Greg Allensworth
author-url: https://github.com/gregallensworth
demo: 
compatible-v0:
compatible-v1: true
---

For use with Cordova/Phonegap, adds tile caching onto local device storage, switching between offline and online mode.
