---
name: Leaflet.TileLayer.Fallback
category: tile-load
repo: https://github.com/ghybs/Leaflet.TileLayer.Fallback
author: ghybs
author-url: https://github.com/ghybs
demo: https://ghybs.github.io/Leaflet.TileLayer.Fallback/examples/tileLayerFallback-demo.html
compatible-v0:
compatible-v1: true
---

Replaces missing Tiles (HTTP 404 Not Found Error) by scaled up equivalent Tiles from lower zooms.
