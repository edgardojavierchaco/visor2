---
name: Leaflet.FeatureGroup.LoadEvents
category: tile-load
repo: https://github.com/Outdooractive/Leaflet.FeatureGroup.LoadEvents
author: G. Lathoud
author-url: http://glat.info/
demo: https://outdooractive.github.io/Leaflet.FeatureGroup.LoadEvents/
compatible-v0: true
compatible-v1: false
---

`FeatureGroup` that supports the `"loading"` and `"load"` events (for v0.7.*).
