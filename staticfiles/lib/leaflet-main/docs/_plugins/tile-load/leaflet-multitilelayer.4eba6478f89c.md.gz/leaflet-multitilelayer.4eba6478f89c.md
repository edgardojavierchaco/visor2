---
name: Leaflet.MultiTileLayer
category: tile-load
repo: https://github.com/mattiasb/Leaflet.MultiTileLayer
author: Mattias Bengtsson
author-url: https://github.com/mattiasb
demo: 
compatible-v0:
compatible-v1: true
---

Allows to compose a TileLayer from several tile sources. Each source is active only on a defined set of zoomlevels.
