---
name: Leaflet.EdgeBuffer
category: tile-load
repo: https://github.com/TolonUK/Leaflet.EdgeBuffer
author: Alex Paterson
author-url: https://github.com/TolonUK
demo: http://www.tolon.co.uk/Leaflet.EdgeBuffer/comparison.html
compatible-v0: false
compatible-v1: true
---

Buffer tiles beyond the edge of the viewport, for Leaflet 1.0.
