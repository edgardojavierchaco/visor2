---
name: TileLayer.PouchDBCached
category: tile-load
repo: https://github.com/MazeMap/Leaflet.TileLayer.PouchDBCached
author: Iván Sánchez Ortega
author-url: https://github.com/IvanSanchez
demo: https://mazemap.github.io/Leaflet.TileLayer.PouchDBCached/demo.html
compatible-v0:
compatible-v1: true
---

Allows all Leaflet TileLayers to cache into PouchDB for offline use.
