---
name: Leaflet.GridLayer.FadeOut
category: tile-load
repo: https://gitlab.com/IvanSanchez/Leaflet.GridLayer.FadeOut
author: Iván Sánchez
author-url: https://github.com/IvanSanchez
demo: https://ivansanchez.gitlab.io/Leaflet.GridLayer.FadeOut/demo.html
compatible-v0: false
compatible-v1: true
---

Fades out grid layers and tilelayers when they are removed, making basemap changes smoother (for 1.0.0).
