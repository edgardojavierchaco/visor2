---
name: leaflet.offline
category: tile-load
repo: https://github.com/allartk/leaflet.offline
author: Allart Kooiman
author-url: https://github.com/allartk
demo: https://allartk.github.io/leaflet.offline/
compatible-v0:
compatible-v1: true
---

Allow tiles to be stored in an database for offline access.
