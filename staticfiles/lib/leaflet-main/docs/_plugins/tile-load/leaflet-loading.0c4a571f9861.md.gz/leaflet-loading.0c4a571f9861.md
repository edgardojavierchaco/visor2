---
name: Leaflet.loading
category: tile-load
repo: https://github.com/ebrelsford/Leaflet.loading
author: Eric Brelsford
author-url: https://github.com/ebrelsford/
demo: http://ebrelsford.github.io/Leaflet.loading/simple.html
compatible-v0:
compatible-v1: true
---

A simple control that adds a loading indicator as tiles and other data are loaded.
