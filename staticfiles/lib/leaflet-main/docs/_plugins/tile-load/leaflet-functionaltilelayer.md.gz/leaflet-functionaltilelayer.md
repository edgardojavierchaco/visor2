---
name: Leaflet.FunctionalTileLayer
category: tile-load
repo: https://github.com/ismyrnow/Leaflet.functionaltilelayer
author: Ishmael Smyrnow
author-url: https://github.com/ismyrnow
demo: 
compatible-v0:
compatible-v1: true
---

Allows you to define tile layer URLs using a function. Even works with asynchronous sources, using promises.
