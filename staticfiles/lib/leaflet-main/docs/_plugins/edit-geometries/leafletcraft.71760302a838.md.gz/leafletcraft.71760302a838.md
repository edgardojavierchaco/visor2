---
name: Leaflet-Craft
category: edit-geometries
repo: https://github.com/sagarpreet-chadha/Leaflet-Craft
author: Sagarpreet Chadha
author-url: https://github.com/sagarpreet-chadha
demo: https://sagarpreet-chadha.github.io/Leaflet-Craft/example/index
compatible-v0:
compatible-v1: true
---

Extends Leaflet.FreeDraw and gives extended features like Undo-Redo, deleting markers,dynamic area calculation of polygons ,various hooks/events and in-build control bars, etc.
