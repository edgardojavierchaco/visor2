---
name: Leaflet.Path.Transform
category: edit-geometries
repo: https://github.com/w8r/Leaflet.Path.Transform
author: Alexander Milevski
author-url: https://github.com/w8r/
demo: https://milevski.co/Leaflet.Path.Transform
compatible-v0:
compatible-v1: true
---

Scale &amp; rotate handler and interaction for polygons and polylines.
