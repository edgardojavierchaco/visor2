---
name: Terra Draw
category: edit-geometries
repo: https://github.com/JamesLMilner/terra-draw
author: James Milner
author-url: https://github.com/JamesLMilner
demo: https://terradraw.io
compatible-v0: false
compatible-v1: true
---

Terra Draw's TerraDrawLeafletAdapter allows users to create, select and edit a variety of geometry types (points, lines polygons etc) on a Leaflet map.
