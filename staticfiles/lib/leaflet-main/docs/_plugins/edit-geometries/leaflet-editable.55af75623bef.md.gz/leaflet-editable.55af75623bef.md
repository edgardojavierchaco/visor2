---
name: Leaflet.Editable
category: edit-geometries
repo: https://github.com/Leaflet/Leaflet.Editable
author: Yohan Boniface
author-url: https://yohanboniface.me/
demo: https://leaflet.github.io/Leaflet.Editable/example/index.html
compatible-v0:
compatible-v1: true
---

Lightweight fully customisable and controllable drawing/editing plugin.
