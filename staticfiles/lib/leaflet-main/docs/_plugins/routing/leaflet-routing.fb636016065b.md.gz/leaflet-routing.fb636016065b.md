---
name: Leaflet.Routing
category: routing
repo: https://github.com/Turistforeningen/leaflet-routing
author: Norwegian Trekking Association
author-url: https://github.com/turistforeningen
demo: 
compatible-v0: true
compatible-v1: false
---

Leaflet controller and interface for routing paths between waypoints using any user provided routing service.
