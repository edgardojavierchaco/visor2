---
name: leaflet-dataclassification
category: dataviz
repo: https://github.com/balladaniel/leaflet-dataclassification
author: Dániel Balla
author-url: https://github.com/balladaniel/
demo: https://balladaniel.github.io/leaflet-dataclassification/examples/combined.html
compatible-v0:
compatible-v1: true
---

Single-step data classification, symbology and legend creation for GeoJSON data powered thematic maps.
