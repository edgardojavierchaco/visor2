---
name: Leaflet.PixiOverlay
category: dataviz
repo: https://github.com/manubb/Leaflet.PixiOverlay
author: Manuel Baclet
author-url: https://github.com/manubb
demo: https://manubb.github.io/Leaflet.PixiOverlay/demo.html
compatible-v0:
compatible-v1: true
---

A Leaflet overlay class for drawing and animating with <a href="https://pixijs.com/">Pixi.js</a>.
