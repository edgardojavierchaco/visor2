---
name: Leaflet.TimeDimension
category: time-elevation
repo: https://github.com/socib/Leaflet.TimeDimension
author: ICTS SOCIB
author-url: https://www.socib.es/
demo: https://apps.socib.es/Leaflet.TimeDimension/examples/index.html
compatible-v0:
compatible-v1: true
---

Add time dimension capabilities on a Leaflet map.
