---
name: Leaflet.timeline
category: time-elevation
repo: https://github.com/skeate/Leaflet.timeline
author: Jonathan Skeate
author-url: https://github.com/skeate
demo: https://skeate.dev/Leaflet.timeline/examples/earthquakes.html
compatible-v0:
compatible-v1: true
---

Display arbitrary GeoJSON on a map with a timeline slider and play button.
