---
name: LeafletSlider-LocalTimeV2
category: time-elevation
repo: https://github.com/carlosign/LeafletSlider-LocalTimeV2
author: Carlos Charletti
author-url: https://github.com/carlosign
demo: https://carlosign.github.io/LeafletSlider-LocalTimeV2/
compatible-v0:
compatible-v1: true
---

LeafletSlider-LocalTimeV2  enables you to dynamically add and remove Markers (without lag) on a map, and show the daterange in localtime by using a JQuery UI slider
