---
name: leaflet-calendar
category: time-elevation
repo: https://github.com/antoniovlx/leaflet-calendar
author: Antonio Vida
author-url: https://github.com/antoniovlx
demo: https://antoniovlx.github.io/leaflet-calendar/examples/index.html
compatible-v0:
compatible-v1: true
---

leaflet-calendar allows you to add a calendar picker and trigger a custom function when a date is selected.
