/*! DataTables styling integration
 * © SpryMedia Ltd - datatables.net/license
 */
import jQuery from"jquery";import DataTable from"datatables.net";let $=jQuery;export default DataTable;